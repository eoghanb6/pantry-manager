const firebaseConfig = {
  apiKey: "AIzaSyAk2ZhanXZL1equdtQZPrZgdoX4hbGInZU",
  authDomain: "pantry-manager-20269.firebaseapp.com",
  databaseURL: "https://pantry-manager-20269.firebaseio.com",
  projectId: "pantry-manager-20269",
  storageBucket: "pantry-manager-20269.appspot.com",
  messagingSenderId: "796386248043",
  appId: "1:796386248043:web:c8b3d8b0b94d58087ff82e",
  measurementId: "G-L969NPMPW0"
}

export default firebaseConfig
